@extends('layouts.app')
@section('title')
Challenge
@stop
@section('css')
<style>
.challenge_section{
    width: 100%;
    box-shadow: 0px 0px 16px rgba(0,0,0,0.21);
    margin-bottom: 50px;
}
.label_challnge_sec{
    width: 590px;
    display:block;
    border: 1px solid #dfdddd;
    margin: 0px auto;
    border-radius:5px;
}
.sectio_absolute{
    width: 100%;
    display: inline-block;
    position: relative;
}
.input_challenge_field{
    width: 93%;
    border: none;
    display: inline-block;  
    height: 39px; 
    padding-left: 23px;
}
.serch_challenge{
    display: inline-block;
    position: absolute;
    top: 7px;
    right: 15px;
}
.cnter_liez_challenge img{
    width: 100%;
    display: inline-block;
    width: 110px;
    height: 110px;
    line-height: 110px;
    border-radius:50%; 
    border: 7px solid #fff;
    box-shadow: 0px 0px 18px rgba(0,0,0,0.35);
}
.challnge_text{
    font-size: 17px;
    color: #232323;
    margin-top: 20px;
    display: inline-block;
    margin-bottom: 15px;
    width: 100%;
}

.chalnge_btn_jhon{
    width: 120px;
    display: inline-block;
    background: #92b713;
    border-radius: 6px;
    color: #fff;
    font-size: 13px;
    text-align: center;
    height: 35px;
    line-height: 35px;
}
.border_arrea{
    border-bottom: 1px solid #c1c1c1;
    display: inline-block;
    padding: 19px 0 30px 0;
}
.pagination{
    width: 100%;
    display: inline-block;
    text-align: center;
    padding: 60px 0;
}
.img-responsive{
        margin: 0 auto !important;
}
.form_area_challenge{
  padding: 40px 0;  
}
@media all and (min-width: 961px) and (max-width: 1200px) {
.col-md-4{
    margin-bottom: 30px;
}
.col-md-6{
    text-align: center;
}
.challenge_section{
    text-align: center;
}
.form_area_challenge{
    padding: 40px 0;
}
.label_challnge_sec{
    margin: 0px auto 0px;
}
}
@media all and (min-width: 768px) and (max-width: 960px) {
.col-md-4{
    margin-bottom: 30px;
}
.col-md-6{
    text-align: center;
}
.challenge_section{
    text-align: center;
}
.form_area_challenge{
    padding: 40px 0;
}
.label_challnge_sec{
    margin: 0px auto 0px;
}
}
@media all and (min-width: 100px) and (max-width: 768px) {
.col-md-4{
    margin-bottom: 30px;
}
.col-md-6{
    text-align: center;
}
.challenge_section{
    text-align: center;
}
.form_area_challenge{
    padding: 40px 0;
}
.label_challnge_sec{
    margin: 0px auto 0px;
    width: 453px;
}
.input_challenge_field{
    padding: 0;
}
}
@media all and (min-width: 100px) and (max-width: 600px) {

}
@media all and (min-width: 100px) and (max-width: 480px) {
.label_challnge_sec{
    margin: 0px auto 0px;
    width: 253px;
}
}
</style>
@endsection
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="page-heading">
               Challenge the Players
            </h1>
            <hr class="light full">
        </div>
        
        <div class="col-md-12">
            <div class=" challenge_section ">
            <form class="form_area_challenge">
                <label class="label_challnge_sec">
                    <div class="sectio_absolute">
                    <input type="text" placeholder="Search player by email" class="input_challenge_field">
                    <a href="#" class="serch_challenge"><img class="img-responsive " src={{URL::to('/img/search_challenge.png')}} alt=""/></a>
                    </div>
                </label>
            </form>
            <div class="border_arrea">
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            </div>
            <div class="border_arrea">
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            </div>
            <div class="border_arrea">
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            </div>
            <div class="border_arrea">
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-6">
                    <div class="cnter_liez_challenge">
                    <img class="img-responsive " src={{URL::to('/img/leader_bord_plyer.png')}} alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <span class="challnge_text">
                        John Mathews
                    </span>
                    <a href="#" class="chalnge_btn_jhon">Challenge Me</a>
                </div>
            </div>
            </div>
            <div class="pagination">
            <img class="img-responsive " src={{URL::to('/img/pagination.png')}} alt=""/>
        </div>
            </div>
        </div>
        
        
    </div>
</div>

@endsection